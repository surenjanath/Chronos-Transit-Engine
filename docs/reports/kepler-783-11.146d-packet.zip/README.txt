Chronos Transit Engine - data packet for one signal
====================================================

summary.json         Target, ephemeris, transit parameters, host star, every vetting measurement, the classifier's
                     verdict, what NASA lists on the star, and the run and audit-trail hash this came from.
folded_transit.csv   The detrended light curve folded on the ephemeris, within the stated window of mid-transit.
                     time_days is the time from mid-transit; flux is normalised to 1 out of transit; flux_err is the
                     robust scatter of the out-of-transit points (one value, repeated).
transit_times.csv    Mid-time of each transit that could be timed on its own, with its error and its difference from
                     a constant period (present only when single transits stand out of the noise).
validation.json      False-positive probability from TRICERATOPS, when it has been run for this signal.

folded_transit.csv is in the form TRICERATOPS, DAVE and similar tools take: time from mid-transit in days, flux, error.
To run TRICERATOPS on it:  python tools/triceratops_validate.py <this packet, unzipped>

Nothing in this packet is a confirmation. It is what one pipeline measured, laid out so that it can be checked.
